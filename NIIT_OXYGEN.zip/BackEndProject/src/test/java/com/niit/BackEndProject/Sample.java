package com.niit.BackEndProject;

import junit.framework.TestCase;

public class Sample extends TestCase {

}
